
/*Author: Elliott Maxwell 7223226
*Target: register.html
*Purpose: This file is for...
*Created: 12.9.18
*Last updated: 12.9.18
*Credits: Lab handout
*/

//step 2, part 2
"use strict";

//step 2, part 1 and 3
function init() {
  var regForm = document.getElementById("regform"); // get ref to the HTML element
  regForm.onsubmit = validate; //register the event listener
  prefill_form();
}

//step 2, part 3 - additional js checks
function validate() {
    // initialise local variables
    var errMsg = ""; //stores the error message
    var result = true; //assumes no errors

    //retrieve data from form
    var firstName = document.getElementById("firstname").value;
    var lastName = document.getElementById("lastname").value;
    var species = getSpecies();
    var age = document.getElementById("age").value;
    var beardSize = document.getElementById("beard").value;
    var numberOfTravellers = document.getElementById("partySize").value;
    var foodSelection = document.getElementById("food").value;
    var is1Day = document.getElementById("1day").checked;
    var is4Day = document.getElementById("4day").checked;
    var is10Day = document.getElementById("10day").checked;
    var human = document.getElementById("human").checked;
    var dwarf = document.getElementById("dwarf").checked;
    var elf = document.getElementById("elf").checked;
    var hobbit = document.getElementById("hobbit").checked;

    //firstname check - not empty and contains only alpha characters
    if (!firstName.match(/^[a-zA-z]+$/)) {
        errMsg += "Your first name must only contain alpha characters\n";
        result = false;
    }

    //lastname check - not empty and contains only alpha characters or a hyphen
    if (!lastName.match(/^[a-zA-Z -]+$/)) {
        errMsg += "Your last name must only contain alpha characters and a hyphen\n";
        result = false;
    }

    //age checks - an integer greater than 18 but less than 10000
    if (isNaN(age)) {
        errMsg += "Your age must be a number\n";
        result = false;
    }
    else if (age < 18) {
        errMsg += "Your age must be 18 or older\n";
        result = false;
    } 
    else if (age > 1000) {
        errMsg += "Your age must be below 10000\n";
        result = false;
    } 
    //step 6, part 3 - invoke checkSpeciesAge() function
    else {
        var temp = checkSpeciesAges(age);
        if (temp != "") {
            errMsg += temp;
            result = false;
        }
    }//end of age checks

    //check food selection - must be selected
    if (foodSelection == "none") {
        errMsg += "You must select a food preference\n";
        result = false;
    }

    //check trip selection - one or more must be selected
    if (!(is1Day || is4Day || is10Day)) {
        errMsg += "Please select at least one trip\n";
        result = false;
    }

    //check species selection - must be selected
    if (!(human || dwarf || elf || hobbit)) {
        errMsg += "You must select a species\n";
        result = false;
    }

    //display error message
    if (errMsg != "") {
        alert(errMsg);
    }

    //task 2, step 2, part 4 - invoke the storeBooking() function
    if (result) { //i.e result == true
        storeBooking(firstName, lastName, age, beardSize, species, is1Day, is4Day, is10Day);
    }
  return result; //if false, no information sent
}

//step 6, part 1 - return the selected species as a string
function getSpecies() {
  //initialise variables
    var speciesName = "Unknown"; //"unknown" used in case not initialised properly
    var speciesArray = document.getElementById("species").getElementsByTagName("input");

    //get an array of all input elements inside the fieldset element with id="species"
    for (var i = 0; i < speciesArray.length; i++) {
        if (speciesArray[i].checked) //test if radio button is selected
            speciesName = speciesArray[i].value; //assign the value attribute
    }//end for
  return speciesName;
}

//step 6, part 2 - check species and age are compatible, return error if rule violated
function checkSpeciesAges(age) {
  //assume the parameter age has already been checked for general constraints e.g. >18
  var errMsg = "";
  var species = getSpecies();
    switch (species) {
        case "Human":
            if (age > 120) {
                errMsg = "You cannot be a human and over 120.\n";
            }//end if
            break;
        case "Dwarf":
        case "Hobbit":
            if (age > 150) {
                errMsg = "You cannot be a " + species + " and over 150.\n";
            }//end if
            break;
        case "Elf": //elves can be any age
            break;
        default:
        errMsg = "We don't allow your kind on our tours.\n";
    }//end switch
    return errMsg;
}

//step 6, part 4 - checks beard length is compatible with species and age, return selected species as a string
function checkSpeciesBeard(beardSize, age) {
    //initialise variables
    var errMsg = "";
    var species = getSpecies();

    switch (species) {
        case "Human": //humans may or may not have a beard
            break;
        case "Dwarf": //Dwarfs over 30 years old always have a beard longer than 12 inches
            if (age >= 30 && beardSize < 12) {
                errMsg = "Your beard is too small for a Dwarf over the age of 30";
            }//end if
            break;
        case "Hobbit": //elves and hobbits never have beards
        case "Elf":
            if (beardSize > 0) {
                errMsg = "You are a " + species + " and therefore cannot have a beard\n";
            }//end if
            break;
        default:
            errMsg = "We don't allow your kind on our tours.\n";
    }//end switch

  return errMsg;
}

//TASK 2
//step 2, part 1
function storeBooking(firstName, lastName, age, species, is1Day, is4Day, is10Day) {
    //get values and assign them to sessionStorage attribute
    //use same name for the attribute and element id to avoid confusion
    var trip = "";
    if(is1Day) trip = "1day";
    if(is4Day) trip += ", 4day";
    if(is10Day) trip += ", 10day";
    sessionStorage.trip = trip;
    sessionStorage.firstName = firstName;
    sessionStorage.lastName = lastName;
    sessionStorage.age = age;
    sessionStorage.species = species;
    sessionStorage.food = document.getElementById("food").value; //not passed as parameter, get from DOM
	sessionStorage.partySize = document.getElementById("partySize").value; //not passed as parameter, get from DOM

}

//step 6 - check if session data on user exists and if so prefill the form
function prefill_form() {

    if (sessionStorage.firstName != undefined) { //if storage for username is not empty
        document.getElementById("firstname").value = sessionStorage.firstName;
        document.getElementById("lastname").value = sessionStorage.lastName;
        document.getElementById("age").value = sessionStorage.age;
        document.getElementById("beard").value = sessionStorage.beardSize;
        document.getElementById("food").value = sessionStorage.food;
        document.getElementById("partySize").value = sessionStorage.partySize;
        switch (localStorage.species) {
            case "Human":
                document.getElementById("human").checked = true;
                break;
             case "Dwarf":
                document.getElementById("dwarf").checked = true;
                break;
            case "Hobbit":
                document.getElementById("hobbit").checked = true;
                break;
            case "Elf":
                document.getElementById("elf").checked = true;
                break;

        }//end switch
    }//end if
}

window.onload = init;

